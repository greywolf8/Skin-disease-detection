#!/usr/bin/env python3
"""
Test script to verify data loading functionality.
"""

import os
import pandas as pd
import sys

def test_metadata_loading():
    """Test loading the metadata file."""
    metadata_path = "attached_assets/bcn20000_metadata_2025-06-22_1750609440007.csv"
    
    print(f"Testing metadata loading...")
    print(f"Metadata path: {metadata_path}")
    print(f"File exists: {os.path.exists(metadata_path)}")
    
    if not os.path.exists(metadata_path):
        print("ERROR: Metadata file not found!")
        return False
    
    try:
        # Load metadata
        df = pd.read_csv(metadata_path)
        print(f"✓ Successfully loaded {len(df)} samples")
        print(f"✓ Columns: {list(df.columns)}")
        
        # Check key columns
        required_columns = ['isic_id', 'diagnosis_1', 'melanocytic', 'age_approx', 'sex']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            print(f"WARNING: Missing columns: {missing_columns}")
        else:
            print(f"✓ All required columns present")
        
        # Show basic statistics
        print(f"\nBasic Statistics:")
        print(f"- Diagnosis distribution: {df['diagnosis_1'].value_counts().head(5).to_dict()}")
        print(f"- Melanocytic distribution: {df['melanocytic'].value_counts().to_dict()}")
        print(f"- Age range: {df['age_approx'].min()}-{df['age_approx'].max()}")
        print(f"- Sex distribution: {df['sex'].value_counts().to_dict()}")
        
        # Check for missing values
        print(f"\nMissing Values:")
        missing_counts = df.isnull().sum()
        for col, count in missing_counts.items():
            if count > 0:
                print(f"- {col}: {count} ({count/len(df)*100:.1f}%)")
        
        return True
        
    except Exception as e:
        print(f"ERROR loading metadata: {str(e)}")
        return False

def test_image_directory():
    """Test the image directory."""
    image_dir = "ISIC-images (2)/"
    
    print(f"\nTesting image directory...")
    print(f"Image directory: {image_dir}")
    print(f"Directory exists: {os.path.exists(image_dir)}")
    
    if os.path.exists(image_dir):
        image_files = [f for f in os.listdir(image_dir) if f.endswith('.jpg')]
        print(f"✓ Found {len(image_files)} image files")
        if image_files:
            print(f"✓ Sample images: {image_files[:3]}")
        return len(image_files) > 0
    else:
        print("WARNING: Image directory not found - prediction will not work")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("SKIN LESION CLASSIFIER - DATA VALIDATION TEST")
    print("=" * 60)
    
    metadata_ok = test_metadata_loading()
    images_ok = test_image_directory()
    
    print(f"\n" + "=" * 60)
    print("SUMMARY:")
    print(f"✓ Metadata loading: {'OK' if metadata_ok else 'FAILED'}")
    print(f"✓ Image directory: {'OK' if images_ok else 'MISSING'}")
    
    if metadata_ok:
        print(f"\n✓ Ready for training and evaluation!")
        if not images_ok:
            print(f"⚠ Note: Without images, only metadata analysis is possible")
    else:
        print(f"\n✗ Cannot proceed - fix metadata loading first")
        sys.exit(1)
    
    print("=" * 60)