"""
Data loading and preprocessing for skin lesion classification.
"""

import os
import pandas as pd
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
import logging

from config import Config
from utils import encode_categorical_features, handle_missing_values, validate_image_path

class SkinLesionDataset(Dataset):
    """Custom dataset for skin lesion images and metadata."""
    
    def __init__(self, df, image_dir, transform=None, is_training=True):
        self.df = df.reset_index(drop=True)
        self.image_dir = image_dir
        self.transform = transform
        self.is_training = is_training
        
        # Validate image paths
        self._validate_images()
        
    def _validate_images(self):
        """Validate that all images exist."""
        valid_indices = []
        for idx, row in self.df.iterrows():
            image_path = os.path.join(self.image_dir, f"{row['isic_id']}.jpg")
            if os.path.exists(image_path):
                valid_indices.append(idx)
            else:
                logging.warning(f"Image not found: {image_path}")
        
        self.df = self.df.iloc[valid_indices].reset_index(drop=True)
        logging.info(f"Dataset initialized with {len(self.df)} valid samples")
    
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        
        # Load image
        image_path = os.path.join(self.image_dir, f"{row['isic_id']}.jpg")
        
        try:
            image = Image.open(image_path).convert('RGB')
            if self.transform:
                image = self.transform(image)
        except Exception as e:
            logging.error(f"Error loading image {image_path}: {str(e)}")
            # Return a black image as fallback
            image = torch.zeros(3, Config.IMAGE_SIZE, Config.IMAGE_SIZE)
        
        # Extract metadata features
        metadata_features = []
        
        # Categorical features
        for feature in Config.CATEGORICAL_FEATURES:
            if feature in row:
                metadata_features.append(float(row[feature]))
            else:
                metadata_features.append(0.0)  # Default value for missing features
        
        # Numerical features
        for feature in Config.NUMERICAL_FEATURES:
            if feature in row:
                value = row[feature] if pd.notna(row[feature]) else 0.0
                metadata_features.append(float(value))
            else:
                metadata_features.append(0.0)
        
        metadata = torch.tensor(metadata_features, dtype=torch.float32)
        
        # Extract targets
        diagnosis_target = row.get('diagnosis_1_encoded', 0)
        melanocytic_target = row.get('melanocytic_encoded', 0)
        
        return {
            'image': image,
            'metadata': metadata,
            'diagnosis_target': torch.tensor(diagnosis_target, dtype=torch.long),
            'melanocytic_target': torch.tensor(melanocytic_target, dtype=torch.long),
            'isic_id': row['isic_id']
        }

class DataProcessor:
    """Handle data loading and preprocessing."""
    
    def __init__(self, metadata_path, image_dir):
        self.metadata_path = metadata_path
        self.image_dir = image_dir
        self.logger = logging.getLogger(__name__)
        
        # Initialize encoders
        self.label_encoders = {}
        self.diagnosis_classes = {}
        self.melanocytic_classes = {True: 1, False: 0}
        
    def load_and_preprocess_data(self):
        """Load and preprocess the metadata."""
        self.logger.info("Loading metadata...")
        
        # Load metadata
        df = pd.read_csv(self.metadata_path)
        self.logger.info(f"Loaded {len(df)} samples from metadata")
        
        # Remove samples with missing primary targets
        initial_size = len(df)
        df = df.dropna(subset=[Config.PRIMARY_TARGET])
        self.logger.info(f"Removed {initial_size - len(df)} samples with missing diagnosis")
        
        # Handle missing values in numerical features
        df = handle_missing_values(df, Config.NUMERICAL_FEATURES)
        
        # Encode categorical features
        df, self.label_encoders = encode_categorical_features(df, Config.CATEGORICAL_FEATURES)
        
        # Encode target variables
        df = self._encode_targets(df)
        
        # Create class mappings
        self._create_class_mappings(df)
        
        self.logger.info(f"Preprocessed dataset with {len(df)} samples")
        self.logger.info(f"Diagnosis classes: {len(self.diagnosis_classes)}")
        self.logger.info(f"Class distribution - Diagnosis: {df['diagnosis_1_encoded'].value_counts().to_dict()}")
        self.logger.info(f"Class distribution - Melanocytic: {df['melanocytic_encoded'].value_counts().to_dict()}")
        
        return df
    
    def _encode_targets(self, df):
        """Encode target variables."""
        # Encode diagnosis_1
        diagnosis_encoder = LabelEncoder()
        df['diagnosis_1_encoded'] = diagnosis_encoder.fit_transform(df[Config.PRIMARY_TARGET].astype(str))
        self.label_encoders['diagnosis_1'] = diagnosis_encoder
        
        # Encode melanocytic (handle missing values)
        df['melanocytic_filled'] = df[Config.SECONDARY_TARGET].fillna(False)
        melanocytic_encoder = LabelEncoder()
        df['melanocytic_encoded'] = melanocytic_encoder.fit_transform(df['melanocytic_filled'].astype(str))
        self.label_encoders['melanocytic'] = melanocytic_encoder
        
        return df
    
    def _create_class_mappings(self, df):
        """Create class name mappings."""
        # Diagnosis classes
        diagnosis_encoder = self.label_encoders['diagnosis_1']
        self.diagnosis_classes = {
            i: label for i, label in enumerate(diagnosis_encoder.classes_)
        }
        
        # Update config
        Config.DIAGNOSIS_CLASSES = self.diagnosis_classes
    
    def get_transforms(self, is_training=True):
        """Get image transforms for training/validation."""
        if is_training:
            return transforms.Compose([
                transforms.Resize((Config.IMAGE_SIZE, Config.IMAGE_SIZE)),
                transforms.RandomRotation(Config.ROTATION_DEGREES),
                transforms.RandomHorizontalFlip(p=Config.HORIZONTAL_FLIP_PROB),
                transforms.RandomVerticalFlip(p=Config.VERTICAL_FLIP_PROB),
                transforms.ColorJitter(
                    brightness=Config.BRIGHTNESS_FACTOR,
                    contrast=Config.CONTRAST_FACTOR
                ),
                transforms.ToTensor(),
                transforms.Normalize(mean=Config.IMAGENET_MEAN, std=Config.IMAGENET_STD)
            ])
        else:
            return transforms.Compose([
                transforms.Resize((Config.IMAGE_SIZE, Config.IMAGE_SIZE)),
                transforms.ToTensor(),
                transforms.Normalize(mean=Config.IMAGENET_MEAN, std=Config.IMAGENET_STD)
            ])
    
    def create_data_loaders(self, df, fold_idx=None, batch_size=None):
        """Create data loaders for training and validation."""
        if batch_size is None:
            batch_size = Config.BATCH_SIZE
        
        if fold_idx is not None:
            # Cross-validation split
            skf = StratifiedKFold(n_splits=Config.K_FOLDS, shuffle=True, random_state=42)
            splits = list(skf.split(df, df['diagnosis_1_encoded']))
            train_idx, val_idx = splits[fold_idx]
            
            train_df = df.iloc[train_idx]
            val_df = df.iloc[val_idx]
        else:
            # Simple train-test split (80-20)
            train_size = int(0.8 * len(df))
            train_df = df[:train_size]
            val_df = df[train_size:]
        
        # Create datasets
        train_dataset = SkinLesionDataset(
            train_df, self.image_dir, 
            transform=self.get_transforms(is_training=True)
        )
        val_dataset = SkinLesionDataset(
            val_df, self.image_dir, 
            transform=self.get_transforms(is_training=False)
        )
        
        # Create data loaders
        train_loader = DataLoader(
            train_dataset, batch_size=batch_size, 
            shuffle=True, num_workers=2, pin_memory=True
        )
        val_loader = DataLoader(
            val_dataset, batch_size=batch_size, 
            shuffle=False, num_workers=2, pin_memory=True
        )
        
        return train_loader, val_loader, train_df, val_df
    
    def prepare_single_prediction(self, image_path, metadata_dict):
        """Prepare data for single image prediction."""
        # Validate image
        validate_image_path(image_path)
        
        # Load and transform image
        image = Image.open(image_path).convert('RGB')
        transform = self.get_transforms(is_training=False)
        image_tensor = transform(image).unsqueeze(0)
        
        # Prepare metadata
        metadata_features = []
        
        # Categorical features
        for feature in Config.CATEGORICAL_FEATURES:
            value = metadata_dict.get(feature, 'unknown')
            if feature in self.label_encoders:
                try:
                    encoded_value = self.label_encoders[feature].transform([str(value)])[0]
                except ValueError:
                    # Handle unseen categories
                    encoded_value = 0
            else:
                encoded_value = 0
            metadata_features.append(float(encoded_value))
        
        # Numerical features
        for feature in Config.NUMERICAL_FEATURES:
            value = metadata_dict.get(feature, 0.0)
            metadata_features.append(float(value))
        
        metadata_tensor = torch.tensor(metadata_features, dtype=torch.float32).unsqueeze(0)
        
        return image_tensor, metadata_tensor
    
    def get_class_names(self, task='diagnosis'):
        """Get class names for specified task."""
        if task == 'diagnosis':
            return list(self.diagnosis_classes.values())
        elif task == 'melanocytic':
            return ['Non-melanocytic', 'Melanocytic']
        else:
            raise ValueError(f"Unknown task: {task}")
