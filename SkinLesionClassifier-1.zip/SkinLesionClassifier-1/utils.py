"""
Utility functions for skin lesion classification system.
"""

import os
import logging
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support, 
    confusion_matrix, classification_report, roc_auc_score
)
from sklearn.preprocessing import LabelEncoder
import torch
import torch.nn.functional as F
from PIL import Image
import cv2

def setup_logging(log_file="training.log"):
    """Setup logging configuration."""
    os.makedirs("logs", exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f"logs/{log_file}"),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def create_directories():
    """Create necessary directories."""
    os.makedirs("checkpoints", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    os.makedirs("visualizations", exist_ok=True)

def encode_categorical_features(df, categorical_columns):
    """Encode categorical features using LabelEncoder."""
    encoders = {}
    df_encoded = df.copy()
    
    for col in categorical_columns:
        if col in df.columns:
            # Handle missing values
            df_encoded[col] = df_encoded[col].fillna('unknown')
            
            # Encode categorical values
            encoder = LabelEncoder()
            df_encoded[col] = encoder.fit_transform(df_encoded[col].astype(str))
            encoders[col] = encoder
    
    return df_encoded, encoders

def handle_missing_values(df, numerical_columns):
    """Handle missing values in numerical columns."""
    df_clean = df.copy()
    
    for col in numerical_columns:
        if col in df.columns:
            # Fill missing values with median
            median_val = df_clean[col].median()
            df_clean[col] = df_clean[col].fillna(median_val)
    
    return df_clean

def calculate_class_weights(labels):
    """Calculate class weights for imbalanced datasets."""
    unique_labels, counts = np.unique(labels, return_counts=True)
    total_samples = len(labels)
    class_weights = {}
    
    for label, count in zip(unique_labels, counts):
        class_weights[label] = total_samples / (len(unique_labels) * count)
    
    return class_weights

def evaluate_model(y_true, y_pred, y_prob=None, target_names=None):
    """Calculate comprehensive evaluation metrics."""
    metrics = {}
    
    # Basic metrics
    metrics['accuracy'] = accuracy_score(y_true, y_pred)
    
    # Precision, Recall, F1
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average='weighted', zero_division=0
    )
    metrics['precision'] = precision
    metrics['recall'] = recall
    metrics['f1'] = f1
    
    # Per-class metrics
    precision_per_class, recall_per_class, f1_per_class, _ = precision_recall_fscore_support(
        y_true, y_pred, average=None, zero_division=0
    )
    metrics['precision_per_class'] = precision_per_class
    metrics['recall_per_class'] = recall_per_class
    metrics['f1_per_class'] = f1_per_class
    
    # AUC-ROC (if probabilities provided)
    if y_prob is not None:
        try:
            if len(np.unique(y_true)) == 2:
                # Binary classification
                metrics['auc_roc'] = roc_auc_score(y_true, y_prob[:, 1])
            else:
                # Multi-class classification
                metrics['auc_roc'] = roc_auc_score(y_true, y_prob, multi_class='ovr')
        except ValueError:
            metrics['auc_roc'] = 0.0
    
    # Confusion matrix
    metrics['confusion_matrix'] = confusion_matrix(y_true, y_pred)
    
    # Classification report
    metrics['classification_report'] = classification_report(
        y_true, y_pred, target_names=target_names, zero_division=0
    )
    
    return metrics

def plot_confusion_matrix(cm, class_names, title="Confusion Matrix", save_path=None):
    """Plot confusion matrix."""
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names)
    plt.title(title)
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path)
    plt.show()

def plot_training_history(train_losses, val_losses, train_accs, val_accs, save_path=None):
    """Plot training history."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
    
    # Loss plot
    ax1.plot(train_losses, label='Training Loss')
    ax1.plot(val_losses, label='Validation Loss')
    ax1.set_title('Model Loss')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Loss')
    ax1.legend()
    ax1.grid(True)
    
    # Accuracy plot
    ax2.plot(train_accs, label='Training Accuracy')
    ax2.plot(val_accs, label='Validation Accuracy')
    ax2.set_title('Model Accuracy')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Accuracy')
    ax2.legend()
    ax2.grid(True)
    
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    plt.show()

class GradCAM:
    """Grad-CAM implementation for model interpretability."""
    
    def __init__(self, model, target_layer):
        self.model = model
        self.target_layer = target_layer
        self.gradients = None
        self.activations = None
        
        # Register hooks
        self.target_layer.register_forward_hook(self.save_activation)
        self.target_layer.register_backward_hook(self.save_gradient)
    
    def save_activation(self, module, input, output):
        self.activations = output
    
    def save_gradient(self, module, grad_input, grad_output):
        self.gradients = grad_output[0]
    
    def generate_cam(self, input_image, class_idx=None):
        """Generate Grad-CAM heatmap."""
        self.model.eval()
        
        # Forward pass
        output = self.model(input_image)
        
        if class_idx is None:
            class_idx = output.argmax(dim=1)
        
        # Backward pass
        self.model.zero_grad()
        class_score = output[:, class_idx]
        class_score.backward()
        
        # Generate CAM
        gradients = self.gradients[0]
        activations = self.activations[0]
        
        # Global average pooling of gradients
        weights = torch.mean(gradients, dim=(1, 2))
        
        # Weighted combination of activation maps
        cam = torch.zeros(activations.shape[1:], dtype=torch.float32)
        for i, w in enumerate(weights):
            cam += w * activations[i, :, :]
        
        # Apply ReLU
        cam = F.relu(cam)
        
        # Normalize
        cam = cam / cam.max()
        
        return cam.detach().numpy()

def overlay_heatmap(image, heatmap, alpha=0.4):
    """Overlay heatmap on original image."""
    # Resize heatmap to match image size
    heatmap_resized = cv2.resize(heatmap, (image.shape[1], image.shape[0]))
    
    # Convert heatmap to colormap
    heatmap_colored = cv2.applyColorMap(
        (heatmap_resized * 255).astype(np.uint8), cv2.COLORMAP_JET
    )
    
    # Overlay
    overlay = cv2.addWeighted(image, 1-alpha, heatmap_colored, alpha, 0)
    
    return overlay

def save_model_checkpoint(model, optimizer, epoch, loss, accuracy, filepath):
    """Save model checkpoint."""
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'loss': loss,
        'accuracy': accuracy
    }
    torch.save(checkpoint, filepath)

def load_model_checkpoint(model, optimizer, filepath):
    """Load model checkpoint."""
    checkpoint = torch.load(filepath, map_location='cpu')
    model.load_state_dict(checkpoint['model_state_dict'])
    if optimizer:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    
    return checkpoint['epoch'], checkpoint['loss'], checkpoint['accuracy']

def validate_image_path(image_path):
    """Validate if image path exists and is valid."""
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image file not found: {image_path}")
    
    try:
        with Image.open(image_path) as img:
            img.verify()
    except Exception as e:
        raise ValueError(f"Invalid image file: {image_path}. Error: {str(e)}")
    
    return True

def format_metrics_output(metrics, title="Evaluation Metrics"):
    """Format metrics for console output."""
    output = f"\n{'='*50}\n{title}\n{'='*50}\n"
    output += f"Accuracy: {metrics['accuracy']:.4f}\n"
    output += f"Precision: {metrics['precision']:.4f}\n"
    output += f"Recall: {metrics['recall']:.4f}\n"
    output += f"F1-Score: {metrics['f1']:.4f}\n"
    
    if 'auc_roc' in metrics:
        output += f"AUC-ROC: {metrics['auc_roc']:.4f}\n"
    
    output += f"\nClassification Report:\n{metrics['classification_report']}\n"
    output += "="*50
    
    return output
