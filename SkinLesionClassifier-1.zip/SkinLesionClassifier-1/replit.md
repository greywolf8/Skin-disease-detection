# Skin Lesion Classification System

## Overview

This repository contains a sophisticated skin lesion classification system designed to work with the BCN20000 dataset. The system implements a hybrid CNN-MLP architecture that combines image analysis with metadata features to classify skin lesions. It's built as a command-line application using PyTorch and includes comprehensive data preprocessing, model training, and evaluation capabilities.

## System Architecture

The application follows a modular, object-oriented architecture with clear separation of concerns:

- **CLI Interface**: Command-line driven application for training, evaluation, and prediction
- **Hybrid Model**: Combines Convolutional Neural Networks (CNN) for image processing with Multi-Layer Perceptrons (MLP) for metadata features
- **Data Pipeline**: Robust data loading and preprocessing system supporting both images and structured metadata
- **Training Framework**: Comprehensive training system with cross-validation, early stopping, and model checkpointing

## Key Components

### 1. Configuration Management (`config.py`)
- Centralized configuration system using a `Config` class
- Hyperparameters: EfficientNetV2-S backbone, 224x224 image size, 32 batch size, 50 epochs
- Training parameters: 5-fold cross-validation, early stopping with patience=10
- File paths and device configuration management

### 2. Data Processing (`data_loader.py`)
- Custom PyTorch `Dataset` class for skin lesion images and metadata
- Image validation and preprocessing with ImageNet normalization
- Metadata feature engineering for categorical and numerical features
- Support for stratified cross-validation

### 3. Model Architecture (`model.py`)
- **Hybrid Architecture**: Combines CNN backbone with metadata MLP
- **Feature Fusion Layer**: Advanced fusion mechanism for combining image and metadata features
- **Multi-task Learning**: Supports prediction of both diagnosis and melanocytic status
- **Backbone Options**: EfficientNetV2-S as primary, with support for ResNet50 and DenseNet121

### 4. Utilities (`utils.py`)
- Comprehensive evaluation metrics (accuracy, precision, recall, F1, AUC-ROC)
- Visualization tools for confusion matrices and training history
- Model checkpoint management and logging utilities
- Data preprocessing helpers for categorical encoding and missing value handling

### 5. Main Application (`lesion_classifier.py`)
- CLI interface using argparse for user interaction
- Complete training pipeline with cross-validation
- Model evaluation and prediction capabilities
- Comprehensive logging and progress tracking

## Data Flow

1. **Data Loading**: CSV metadata is loaded and matched with corresponding JPEG images using `isic_id`
2. **Preprocessing**: Images are resized to 224x224, normalized using ImageNet standards, and augmented during training
3. **Feature Engineering**: Categorical features are encoded, numerical features are normalized, and missing values are handled
4. **Model Training**: Hybrid model processes images through CNN backbone and metadata through MLP, then fuses features
5. **Evaluation**: Stratified k-fold cross-validation with comprehensive metrics and visualization

## External Dependencies

### Core ML/DL Framework
- **PyTorch & TorchVision**: Deep learning framework and computer vision utilities
- **scikit-learn**: Machine learning utilities for preprocessing and evaluation
- **imbalanced-learn**: Handling class imbalance in the dataset

### Data Processing
- **pandas & numpy**: Data manipulation and numerical computing
- **Pillow & OpenCV**: Image processing and computer vision
- **matplotlib & seaborn**: Data visualization and plotting

### Development Tools
- **tqdm**: Progress bars for training loops
- **logging**: Comprehensive logging system

## Deployment Strategy

The application is configured for deployment on Replit with:

- **Environment**: Python 3.11 with Nix package management
- **GPU Support**: Automatic CUDA detection with CPU fallback
- **Dependencies**: Managed through `pyproject.toml` with PyTorch CPU index for Replit compatibility
- **Execution**: Command-line interface accessible through shell commands

The `.replit` configuration includes workflow automation for dependency installation and help display. The system is designed to be self-contained and can run entirely within the Replit environment.

## Changelog

```
Changelog:
- June 22, 2025. Initial setup - Complete CLI-based skin lesion classification system
  * Hybrid CNN-MLP architecture with EfficientNetV2-S backbone
  * Multi-task learning for diagnosis and melanocytic classification
  * 5-fold stratified cross-validation with early stopping
  * Support for 18,946 BCN20000 dataset samples
  * Class imbalance handling with weighted loss functions
  * Comprehensive evaluation metrics and visualization
  * CLI interface for training, evaluation, and single image prediction
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```