"""
Configuration file for skin lesion classification system.
Contains all hyperparameters and settings.
"""

import torch

class Config:
    # Data paths
    METADATA_PATH = "attached_assets/bcn20000_metadata_2025-06-22_1750609440007.csv"
    IMAGE_DIR = "ISIC-images (2)/"
    
    # Model parameters
    IMAGE_SIZE = 224
    BATCH_SIZE = 32
    NUM_EPOCHS = 50
    LEARNING_RATE = 0.001
    WEIGHT_DECAY = 1e-4
    
    # Training parameters
    K_FOLDS = 5
    EARLY_STOPPING_PATIENCE = 10
    MIN_DELTA = 0.001
    
    # Image normalization (ImageNet standards)
    IMAGENET_MEAN = [0.485, 0.456, 0.406]
    IMAGENET_STD = [0.229, 0.224, 0.225]
    
    # Model architecture
    BACKBONE = "efficientnet_v2_s"  # Options: efficientnet_v2_s, resnet50, densenet121
    DROPOUT_RATE = 0.3
    HIDDEN_SIZE = 512
    
    # Device configuration
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # File paths
    MODEL_CHECKPOINT_DIR = "checkpoints/"
    BEST_MODEL_PATH = "checkpoints/best_model.pt"
    LOGS_DIR = "logs/"
    
    # Metadata features
    CATEGORICAL_FEATURES = [
        'anatom_site_general', 'anatom_site_special', 'concomitant_biopsy',
        'diagnosis_confirm_type', 'image_type', 'sex'
    ]
    NUMERICAL_FEATURES = ['age_approx']
    
    # Target variables
    PRIMARY_TARGET = 'diagnosis_1'
    SECONDARY_TARGET = 'melanocytic'
    
    # Class mappings (will be updated during data loading)
    DIAGNOSIS_CLASSES = {}
    MELANOCYTIC_CLASSES = {True: 1, False: 0}
    
    # Data augmentation parameters
    ROTATION_DEGREES = 30
    BRIGHTNESS_FACTOR = 0.2
    CONTRAST_FACTOR = 0.2
    HORIZONTAL_FLIP_PROB = 0.5
    VERTICAL_FLIP_PROB = 0.2
