"""
Hybrid CNN-MLP model for skin lesion classification.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
import logging

from config import Config

class FeatureFusionLayer(nn.Module):
    """Feature fusion layer to combine image and metadata features."""
    
    def __init__(self, image_feature_size, metadata_feature_size, hidden_size):
        super(FeatureFusionLayer, self).__init__()
        
        self.image_projection = nn.Sequential(
            nn.Linear(image_feature_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(Config.DROPOUT_RATE)
        )
        
        self.metadata_projection = nn.Sequential(
            nn.Linear(metadata_feature_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(Config.DROPOUT_RATE)
        )
        
        self.fusion_layer = nn.Sequential(
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Dropout(Config.DROPOUT_RATE),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(Config.DROPOUT_RATE)
        )
    
    def forward(self, image_features, metadata_features):
        # Project features to same dimension
        image_proj = self.image_projection(image_features)
        metadata_proj = self.metadata_projection(metadata_features)
        
        # Concatenate and fuse
        combined = torch.cat([image_proj, metadata_proj], dim=1)
        fused_features = self.fusion_layer(combined)
        
        return fused_features

class AttentionLayer(nn.Module):
    """Simple attention mechanism for feature weighting."""
    
    def __init__(self, feature_size):
        super(AttentionLayer, self).__init__()
        self.attention = nn.Sequential(
            nn.Linear(feature_size, feature_size // 2),
            nn.ReLU(),
            nn.Linear(feature_size // 2, feature_size),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        attention_weights = self.attention(x)
        return x * attention_weights

class HybridSkinLesionClassifier(nn.Module):
    """Hybrid CNN-MLP model for skin lesion classification."""
    
    def __init__(self, num_diagnosis_classes, num_metadata_features, backbone='efficientnet_v2_s'):
        super(HybridSkinLesionClassifier, self).__init__()
        
        self.backbone_name = backbone
        self.num_diagnosis_classes = num_diagnosis_classes
        self.num_metadata_features = num_metadata_features
        
        # Initialize CNN backbone
        self._init_backbone()
        
        # Feature fusion layer
        self.feature_fusion = FeatureFusionLayer(
            self.cnn_feature_size, 
            num_metadata_features, 
            Config.HIDDEN_SIZE
        )
        
        # Attention layer
        self.attention = AttentionLayer(Config.HIDDEN_SIZE)
        
        # Classification heads
        self.diagnosis_classifier = nn.Sequential(
            nn.Linear(Config.HIDDEN_SIZE, Config.HIDDEN_SIZE // 2),
            nn.ReLU(),
            nn.Dropout(Config.DROPOUT_RATE),
            nn.Linear(Config.HIDDEN_SIZE // 2, num_diagnosis_classes)
        )
        
        self.melanocytic_classifier = nn.Sequential(
            nn.Linear(Config.HIDDEN_SIZE, Config.HIDDEN_SIZE // 2),
            nn.ReLU(),
            nn.Dropout(Config.DROPOUT_RATE),
            nn.Linear(Config.HIDDEN_SIZE // 2, 2)  # Binary classification
        )
        
        # Initialize weights
        self._initialize_weights()
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Initialized {backbone} backbone with {self.cnn_feature_size} features")
    
    def _init_backbone(self):
        """Initialize CNN backbone."""
        if self.backbone_name == 'efficientnet_v2_s':
            self.backbone = models.efficientnet_v2_s(pretrained=True)
            self.cnn_feature_size = self.backbone.classifier[1].in_features
            self.backbone.classifier = nn.Identity()  # Remove original classifier
            
        elif self.backbone_name == 'resnet50':
            self.backbone = models.resnet50(pretrained=True)
            self.cnn_feature_size = self.backbone.fc.in_features
            self.backbone.fc = nn.Identity()  # Remove original classifier
            
        elif self.backbone_name == 'densenet121':
            self.backbone = models.densenet121(pretrained=True)
            self.cnn_feature_size = self.backbone.classifier.in_features
            self.backbone.classifier = nn.Identity()  # Remove original classifier
            
        else:
            raise ValueError(f"Unsupported backbone: {self.backbone_name}")
    
    def _initialize_weights(self):
        """Initialize custom layer weights."""
        for module in [self.feature_fusion, self.attention, 
                      self.diagnosis_classifier, self.melanocytic_classifier]:
            for m in module.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)
    
    def forward(self, image, metadata):
        # Extract image features
        image_features = self.backbone(image)
        
        # Flatten if needed (for some backbones)
        if len(image_features.shape) > 2:
            image_features = torch.flatten(image_features, 1)
        
        # Fuse features
        fused_features = self.feature_fusion(image_features, metadata)
        
        # Apply attention
        attended_features = self.attention(fused_features)
        
        # Classification
        diagnosis_output = self.diagnosis_classifier(attended_features)
        melanocytic_output = self.melanocytic_classifier(attended_features)
        
        return diagnosis_output, melanocytic_output
    
    def get_feature_maps(self, image):
        """Get intermediate feature maps for Grad-CAM."""
        features = {}
        
        def hook_fn(name):
            def hook(module, input, output):
                features[name] = output
            return hook
        
        # Register hooks for different backbones
        if self.backbone_name == 'efficientnet_v2_s':
            self.backbone.features[-1].register_forward_hook(hook_fn('features'))
        elif self.backbone_name == 'resnet50':
            self.backbone.layer4.register_forward_hook(hook_fn('features'))
        elif self.backbone_name == 'densenet121':
            self.backbone.features.register_forward_hook(hook_fn('features'))
        
        # Forward pass
        _ = self.backbone(image)
        
        return features.get('features', None)

class ModelTrainer:
    """Training and evaluation utilities for the hybrid model."""
    
    def __init__(self, model, device=None):
        self.model = model
        self.device = device or Config.DEVICE
        self.model.to(self.device)
        
        self.logger = logging.getLogger(__name__)
        
        # Loss functions
        self.diagnosis_criterion = nn.CrossEntropyLoss()
        self.melanocytic_criterion = nn.CrossEntropyLoss()
        
        # Optimizer
        self.optimizer = torch.optim.AdamW(
            model.parameters(), 
            lr=Config.LEARNING_RATE, 
            weight_decay=Config.WEIGHT_DECAY
        )
        
        # Learning rate scheduler
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=Config.NUM_EPOCHS
        )
        
        # Early stopping
        self.best_val_loss = float('inf')
        self.patience_counter = 0
        
        # Training history
        self.train_losses = []
        self.val_losses = []
        self.train_accuracies = []
        self.val_accuracies = []
    
    def train_epoch(self, train_loader):
        """Train for one epoch."""
        self.model.train()
        total_loss = 0.0
        correct_diagnosis = 0
        correct_melanocytic = 0
        total_samples = 0
        
        for batch in train_loader:
            images = batch['image'].to(self.device)
            metadata = batch['metadata'].to(self.device)
            diagnosis_targets = batch['diagnosis_target'].to(self.device)
            melanocytic_targets = batch['melanocytic_target'].to(self.device)
            
            # Forward pass
            diagnosis_outputs, melanocytic_outputs = self.model(images, metadata)
            
            # Calculate losses
            diagnosis_loss = self.diagnosis_criterion(diagnosis_outputs, diagnosis_targets)
            melanocytic_loss = self.melanocytic_criterion(melanocytic_outputs, melanocytic_targets)
            
            # Combined loss (weighted)
            total_loss_batch = diagnosis_loss + 0.5 * melanocytic_loss
            
            # Backward pass
            self.optimizer.zero_grad()
            total_loss_batch.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            
            self.optimizer.step()
            
            # Statistics
            total_loss += total_loss_batch.item()
            
            _, diagnosis_predicted = torch.max(diagnosis_outputs.data, 1)
            _, melanocytic_predicted = torch.max(melanocytic_outputs.data, 1)
            
            correct_diagnosis += (diagnosis_predicted == diagnosis_targets).sum().item()
            correct_melanocytic += (melanocytic_predicted == melanocytic_targets).sum().item()
            total_samples += diagnosis_targets.size(0)
        
        avg_loss = total_loss / len(train_loader)
        diagnosis_accuracy = correct_diagnosis / total_samples
        melanocytic_accuracy = correct_melanocytic / total_samples
        avg_accuracy = (diagnosis_accuracy + melanocytic_accuracy) / 2
        
        return avg_loss, avg_accuracy, diagnosis_accuracy, melanocytic_accuracy
    
    def validate_epoch(self, val_loader):
        """Validate for one epoch."""
        self.model.eval()
        total_loss = 0.0
        correct_diagnosis = 0
        correct_melanocytic = 0
        total_samples = 0
        
        all_diagnosis_targets = []
        all_diagnosis_outputs = []
        all_melanocytic_targets = []
        all_melanocytic_outputs = []
        
        with torch.no_grad():
            for batch in val_loader:
                images = batch['image'].to(self.device)
                metadata = batch['metadata'].to(self.device)
                diagnosis_targets = batch['diagnosis_target'].to(self.device)
                melanocytic_targets = batch['melanocytic_target'].to(self.device)
                
                # Forward pass
                diagnosis_outputs, melanocytic_outputs = self.model(images, metadata)
                
                # Calculate losses
                diagnosis_loss = self.diagnosis_criterion(diagnosis_outputs, diagnosis_targets)
                melanocytic_loss = self.melanocytic_criterion(melanocytic_outputs, melanocytic_targets)
                
                # Combined loss
                total_loss_batch = diagnosis_loss + 0.5 * melanocytic_loss
                total_loss += total_loss_batch.item()
                
                # Statistics
                _, diagnosis_predicted = torch.max(diagnosis_outputs.data, 1)
                _, melanocytic_predicted = torch.max(melanocytic_outputs.data, 1)
                
                correct_diagnosis += (diagnosis_predicted == diagnosis_targets).sum().item()
                correct_melanocytic += (melanocytic_predicted == melanocytic_targets).sum().item()
                total_samples += diagnosis_targets.size(0)
                
                # Collect for detailed metrics
                all_diagnosis_targets.extend(diagnosis_targets.cpu().numpy())
                all_diagnosis_outputs.extend(torch.softmax(diagnosis_outputs, dim=1).cpu().numpy())
                all_melanocytic_targets.extend(melanocytic_targets.cpu().numpy())
                all_melanocytic_outputs.extend(torch.softmax(melanocytic_outputs, dim=1).cpu().numpy())
        
        avg_loss = total_loss / len(val_loader)
        diagnosis_accuracy = correct_diagnosis / total_samples
        melanocytic_accuracy = correct_melanocytic / total_samples
        avg_accuracy = (diagnosis_accuracy + melanocytic_accuracy) / 2
        
        return (avg_loss, avg_accuracy, diagnosis_accuracy, melanocytic_accuracy,
                all_diagnosis_targets, all_diagnosis_outputs,
                all_melanocytic_targets, all_melanocytic_outputs)
    
    def should_early_stop(self, val_loss):
        """Check if training should stop early."""
        if val_loss < self.best_val_loss - Config.MIN_DELTA:
            self.best_val_loss = val_loss
            self.patience_counter = 0
            return False
        else:
            self.patience_counter += 1
            return self.patience_counter >= Config.EARLY_STOPPING_PATIENCE
    
    def step_scheduler(self):
        """Step the learning rate scheduler."""
        self.scheduler.step()
    
    def get_current_lr(self):
        """Get current learning rate."""
        return self.optimizer.param_groups[0]['lr']
