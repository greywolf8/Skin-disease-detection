#!/usr/bin/env python3
"""
Demo training script that works without images for testing the system.
"""

import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report
import logging

from config import Config
from utils import setup_logging, create_directories, encode_categorical_features, handle_missing_values

def create_metadata_only_model(num_diagnosis_classes, num_metadata_features):
    """Create a simple MLP model for metadata-only training."""
    return nn.Sequential(
        nn.Linear(num_metadata_features, 256),
        nn.ReLU(),
        nn.Dropout(0.3),
        nn.Linear(256, 128),
        nn.ReLU(),
        nn.Dropout(0.3),
        nn.Linear(128, 64),
        nn.ReLU(),
        nn.Dropout(0.3),
        nn.Linear(64, num_diagnosis_classes)
    )

def demo_training():
    """Demonstrate training with metadata only."""
    
    # Setup
    logger = setup_logging("demo_training.log")
    create_directories()
    
    print("SKIN LESION CLASSIFIER - DEMO TRAINING")
    print("=" * 50)
    print("Training with metadata features only (no images)")
    
    # Load and preprocess data
    df = pd.read_csv(Config.METADATA_PATH)
    print(f"Loaded {len(df)} samples")
    
    # Remove samples with missing diagnosis
    df_clean = df.dropna(subset=['diagnosis_1'])
    print(f"Samples with valid diagnosis: {len(df_clean)}")
    
    # Handle missing values
    df_processed = handle_missing_values(df_clean, Config.NUMERICAL_FEATURES)
    
    # Encode categorical features
    df_encoded, encoders = encode_categorical_features(df_processed, Config.CATEGORICAL_FEATURES)
    
    # Encode targets
    diagnosis_encoder = LabelEncoder()
    df_encoded['diagnosis_encoded'] = diagnosis_encoder.fit_transform(df_encoded['diagnosis_1'])
    
    # Prepare features
    feature_cols = Config.CATEGORICAL_FEATURES + Config.NUMERICAL_FEATURES
    X = df_encoded[feature_cols].values
    y = df_encoded['diagnosis_encoded'].values
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"Training samples: {len(X_train)}")
    print(f"Test samples: {len(X_test)}")
    print(f"Features: {len(feature_cols)}")
    print(f"Classes: {len(diagnosis_encoder.classes_)}")
    
    # Convert to tensors
    X_train_tensor = torch.FloatTensor(X_train)
    X_test_tensor = torch.FloatTensor(X_test)
    y_train_tensor = torch.LongTensor(y_train)
    y_test_tensor = torch.LongTensor(y_test)
    
    # Create model
    model = create_metadata_only_model(
        num_diagnosis_classes=len(diagnosis_encoder.classes_),
        num_metadata_features=len(feature_cols)
    )
    
    # Training setup
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    print("\nStarting training...")
    
    # Training loop
    model.train()
    epochs = 20
    batch_size = 64
    
    for epoch in range(epochs):
        total_loss = 0
        correct = 0
        total = 0
        
        # Mini-batch training
        for i in range(0, len(X_train_tensor), batch_size):
            batch_X = X_train_tensor[i:i+batch_size]
            batch_y = y_train_tensor[i:i+batch_size]
            
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += batch_y.size(0)
            correct += (predicted == batch_y).sum().item()
        
        accuracy = 100 * correct / total
        
        if epoch % 5 == 0 or epoch == epochs - 1:
            print(f"Epoch {epoch+1}/{epochs} - Loss: {total_loss/len(X_train_tensor)*batch_size:.4f} - Accuracy: {accuracy:.2f}%")
    
    # Evaluation
    model.eval()
    with torch.no_grad():
        test_outputs = model(X_test_tensor)
        _, test_predicted = torch.max(test_outputs, 1)
        test_accuracy = accuracy_score(y_test, test_predicted.numpy())
        
        print(f"\nTest Accuracy: {test_accuracy:.4f}")
        print("\nClassification Report:")
        print(classification_report(y_test, test_predicted.numpy(), 
                                  target_names=diagnosis_encoder.classes_))
    
    print("\n" + "=" * 50)
    print("DEMO TRAINING COMPLETED SUCCESSFULLY")
    print("This demonstrates the system works with metadata features.")
    print("Add image directory to enable full hybrid CNN-MLP training.")
    print("=" * 50)

if __name__ == "__main__":
    demo_training()