#!/usr/bin/env python3
"""
Demonstration script for the skin lesion classification system.
Shows system capabilities and data analysis without requiring images.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from config import Config
from data_loader import DataProcessor
from utils import setup_logging, create_directories, encode_categorical_features, handle_missing_values

def analyze_dataset():
    """Comprehensive analysis of the BCN20000 dataset."""
    
    # Setup
    logger = setup_logging("demo.log")
    create_directories()
    
    logger.info("Starting dataset analysis...")
    
    # Load data
    df = pd.read_csv(Config.METADATA_PATH)
    logger.info(f"Loaded {len(df)} samples")
    
    print("=" * 80)
    print("SKIN LESION CLASSIFICATION SYSTEM - DATASET ANALYSIS")
    print("=" * 80)
    
    # Basic statistics
    print(f"\n📊 DATASET OVERVIEW")
    print(f"Total samples: {len(df):,}")
    print(f"Total features: {len(df.columns)}")
    print(f"Memory usage: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
    
    # Target variable analysis
    print(f"\n🎯 TARGET VARIABLES")
    
    # Diagnosis distribution
    diagnosis_clean = df['diagnosis_1'].dropna()
    print(f"\nDiagnosis Classification ({len(diagnosis_clean)} valid samples):")
    for diag, count in diagnosis_clean.value_counts().head(10).items():
        percentage = count / len(diagnosis_clean) * 100
        print(f"  {diag}: {count:,} ({percentage:.1f}%)")
    
    # Melanocytic distribution
    melanocytic_clean = df['melanocytic'].dropna()
    print(f"\nMelanocytic Classification ({len(melanocytic_clean)} valid samples):")
    for status, count in melanocytic_clean.value_counts().items():
        percentage = count / len(melanocytic_clean) * 100
        status_label = "Melanocytic" if status else "Non-melanocytic"
        print(f"  {status_label}: {count:,} ({percentage:.1f}%)")
    
    # Feature analysis
    print(f"\n📋 FEATURE ANALYSIS")
    
    # Age distribution
    age_clean = df['age_approx'].dropna()
    print(f"\nAge Distribution ({len(age_clean)} valid samples):")
    print(f"  Mean: {age_clean.mean():.1f} years")
    print(f"  Median: {age_clean.median():.1f} years")
    print(f"  Range: {age_clean.min():.0f} - {age_clean.max():.0f} years")
    print(f"  Standard deviation: {age_clean.std():.1f} years")
    
    # Anatomical site distribution
    site_clean = df['anatom_site_general'].dropna()
    print(f"\nAnatomical Sites ({len(site_clean)} valid samples):")
    for site, count in site_clean.value_counts().head(8).items():
        percentage = count / len(site_clean) * 100
        print(f"  {site}: {count:,} ({percentage:.1f}%)")
    
    # Sex distribution
    sex_clean = df['sex'].dropna()
    print(f"\nSex Distribution ({len(sex_clean)} valid samples):")
    for sex, count in sex_clean.value_counts().items():
        percentage = count / len(sex_clean) * 100
        print(f"  {sex.title()}: {count:,} ({percentage:.1f}%)")
    
    # Data quality assessment
    print(f"\n🔍 DATA QUALITY ASSESSMENT")
    
    missing_data = df.isnull().sum().sort_values(ascending=False)
    print(f"\nMissing Data by Column:")
    for col, missing_count in missing_data.items():
        if missing_count > 0:
            percentage = missing_count / len(df) * 100
            print(f"  {col}: {missing_count:,} ({percentage:.1f}%)")
    
    # Class balance analysis
    print(f"\n⚖️ CLASS BALANCE ANALYSIS")
    
    # Calculate imbalance ratios
    if not diagnosis_clean.empty:
        diagnosis_counts = diagnosis_clean.value_counts()
        majority_class = diagnosis_counts.iloc[0]
        minority_class = diagnosis_counts.iloc[-1]
        imbalance_ratio = majority_class / minority_class
        print(f"\nDiagnosis Imbalance Ratio: {imbalance_ratio:.2f}:1")
        print(f"  Most common: {diagnosis_counts.index[0]} ({majority_class:,} samples)")
        print(f"  Least common: {diagnosis_counts.index[-1]} ({minority_class:,} samples)")
    
    if not melanocytic_clean.empty:
        melanocytic_counts = melanocytic_clean.value_counts()
        mel_ratio = melanocytic_counts.iloc[0] / melanocytic_counts.iloc[1]
        print(f"\nMelanocytic Imbalance Ratio: {mel_ratio:.2f}:1")
    
    # Feature correlation analysis (for numerical features)
    print(f"\n🔗 FEATURE CORRELATIONS")
    
    numerical_cols = ['age_approx']
    if len(numerical_cols) > 0:
        corr_data = df[numerical_cols + ['melanocytic']].dropna()
        if len(corr_data) > 0:
            correlations = corr_data.corr()['melanocytic'].drop('melanocytic')
            print(f"\nCorrelation with Melanocytic Status:")
            for feature, corr in correlations.items():
                print(f"  {feature}: {corr:.3f}")
    
    # Model architecture summary
    print(f"\n🏗️ MODEL ARCHITECTURE SUMMARY")
    print(f"\nHybrid CNN-MLP Architecture:")
    print(f"  CNN Backbone: {Config.BACKBONE}")
    print(f"  Image Size: {Config.IMAGE_SIZE}x{Config.IMAGE_SIZE}")
    print(f"  Categorical Features: {len(Config.CATEGORICAL_FEATURES)}")
    print(f"  Numerical Features: {len(Config.NUMERICAL_FEATURES)}")
    print(f"  Hidden Size: {Config.HIDDEN_SIZE}")
    print(f"  Dropout Rate: {Config.DROPOUT_RATE}")
    
    print(f"\nTraining Configuration:")
    print(f"  Batch Size: {Config.BATCH_SIZE}")
    print(f"  Learning Rate: {Config.LEARNING_RATE}")
    print(f"  Max Epochs: {Config.NUM_EPOCHS}")
    print(f"  K-Fold CV: {Config.K_FOLDS}")
    print(f"  Early Stopping Patience: {Config.EARLY_STOPPING_PATIENCE}")
    
    # System requirements
    print(f"\n💻 SYSTEM REQUIREMENTS")
    print(f"\nTo complete training, you need:")
    print(f"  1. Image directory: '{Config.IMAGE_DIR}' with JPEG files")
    print(f"  2. Images named as: ISIC_XXXXXXX.jpg (matching isic_id)")
    print(f"  3. Estimated {len(df)} images for full dataset")
    
    print(f"\nCurrent Status:")
    print(f"  ✓ Metadata loaded and validated")
    print(f"  ✓ CLI interface ready")
    print(f"  ✓ Model architecture defined")
    print(f"  ✗ Image directory missing")
    
    print(f"\n" + "=" * 80)
    print("READY FOR TRAINING ONCE IMAGES ARE PROVIDED")
    print("=" * 80)
    
    return df

def demonstrate_preprocessing():
    """Demonstrate data preprocessing capabilities."""
    
    print(f"\n🔧 PREPROCESSING DEMONSTRATION")
    
    # Load raw data
    df = pd.read_csv(Config.METADATA_PATH)
    print(f"\nOriginal dataset: {len(df)} samples")
    
    # Remove samples with missing primary targets
    df_clean = df.dropna(subset=[Config.PRIMARY_TARGET])
    print(f"After removing missing diagnosis: {len(df_clean)} samples")
    
    # Handle missing values
    df_processed = handle_missing_values(df_clean, Config.NUMERICAL_FEATURES)
    
    # Encode categorical features
    df_encoded, encoders = encode_categorical_features(df_processed, Config.CATEGORICAL_FEATURES)
    
    print(f"Categorical encoders created: {len(encoders)}")
    print(f"Features after encoding: {len(Config.CATEGORICAL_FEATURES + Config.NUMERICAL_FEATURES)}")
    
    # Show encoding examples
    if 'sex' in encoders:
        print(f"\nSex encoding: {dict(zip(encoders['sex'].classes_, range(len(encoders['sex'].classes_))))}")
    
    if 'anatom_site_general' in encoders:
        site_mapping = dict(zip(encoders['anatom_site_general'].classes_, 
                              range(len(encoders['anatom_site_general'].classes_))))
        print(f"Anatomical sites encoded: {len(site_mapping)} unique sites")
    
    return df_encoded

if __name__ == "__main__":
    # Run comprehensive analysis
    dataset = analyze_dataset()
    
    # Demonstrate preprocessing
    processed_data = demonstrate_preprocessing()
    
    print(f"\n✅ DEMONSTRATION COMPLETE")
    print(f"The system is ready to train once you provide the image directory.")
    print(f"Use 'python lesion_classifier.py --help' to see all available commands.")