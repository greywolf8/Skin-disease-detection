#!/usr/bin/env python3
"""
Sophisticated CLI-based skin lesion classification system using hybrid CNN-MLP architecture.
Multi-task learning for diagnosis and melanocytic status prediction.
"""

import argparse
import os
import sys
import logging
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import StratifiedKFold
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

# Import custom modules
from config import Config
from data_loader import DataProcessor
from model import HybridSkinLesionClassifier, ModelTrainer
from utils import (
    setup_logging, create_directories, evaluate_model, 
    plot_confusion_matrix, plot_training_history, 
    save_model_checkpoint, load_model_checkpoint,
    format_metrics_output, calculate_class_weights
)

class SkinLesionCLI:
    """Main CLI application for skin lesion classification."""
    
    def __init__(self):
        self.logger = setup_logging()
        create_directories()
        
        # Initialize data processor
        self.data_processor = DataProcessor(Config.METADATA_PATH, Config.IMAGE_DIR)
        
        # Load and preprocess data
        self.df = None
        self.model = None
        self.trainer = None
        
    def load_data(self):
        """Load and preprocess the dataset."""
        if self.df is None:
            self.logger.info("Loading and preprocessing data...")
            self.df = self.data_processor.load_and_preprocess_data()
            self.logger.info(f"Dataset loaded with {len(self.df)} samples")
        return self.df
    
    def initialize_model(self):
        """Initialize the hybrid model."""
        if self.model is None:
            # Load data to get feature dimensions
            df = self.load_data()
            
            # Calculate feature dimensions
            num_diagnosis_classes = len(Config.DIAGNOSIS_CLASSES)
            num_metadata_features = len(Config.CATEGORICAL_FEATURES) + len(Config.NUMERICAL_FEATURES)
            
            self.logger.info(f"Initializing model with {num_diagnosis_classes} diagnosis classes")
            self.logger.info(f"Metadata features: {num_metadata_features}")
            
            # Initialize model
            self.model = HybridSkinLesionClassifier(
                num_diagnosis_classes=num_diagnosis_classes,
                num_metadata_features=num_metadata_features,
                backbone=Config.BACKBONE
            )
            
            # Initialize trainer
            self.trainer = ModelTrainer(self.model, Config.DEVICE)
            
            self.logger.info(f"Model initialized on device: {Config.DEVICE}")
    
    def train_model(self, args):
        """Train the model using k-fold cross-validation."""
        self.logger.info("Starting model training...")
        
        # Initialize model
        self.initialize_model()
        
        # Load data
        df = self.load_data()
        
        # Cross-validation setup
        skf = StratifiedKFold(n_splits=Config.K_FOLDS, shuffle=True, random_state=42)
        fold_results = []
        
        for fold, (train_idx, val_idx) in enumerate(skf.split(df, df['diagnosis_1_encoded'])):
            self.logger.info(f"\n{'='*50}")
            self.logger.info(f"FOLD {fold + 1}/{Config.K_FOLDS}")
            self.logger.info(f"{'='*50}")
            
            # Create data loaders
            train_loader, val_loader, train_df, val_df = self.data_processor.create_data_loaders(
                df, fold_idx=fold, batch_size=args.batch_size
            )
            
            # Reset model and trainer for each fold
            self.initialize_model()
            
            # Calculate class weights for this fold
            diagnosis_weights = calculate_class_weights(train_df['diagnosis_1_encoded'].values)
            melanocytic_weights = calculate_class_weights(train_df['melanocytic_encoded'].values)
            
            # Update loss functions with class weights
            diagnosis_weight_tensor = torch.tensor([
                diagnosis_weights.get(i, 1.0) for i in range(len(Config.DIAGNOSIS_CLASSES))
            ], dtype=torch.float32).to(Config.DEVICE)
            
            melanocytic_weight_tensor = torch.tensor([
                melanocytic_weights.get(i, 1.0) for i in range(2)
            ], dtype=torch.float32).to(Config.DEVICE)
            
            self.trainer.diagnosis_criterion = torch.nn.CrossEntropyLoss(weight=diagnosis_weight_tensor)
            self.trainer.melanocytic_criterion = torch.nn.CrossEntropyLoss(weight=melanocytic_weight_tensor)
            
            # Training loop
            best_val_accuracy = 0.0
            
            for epoch in range(args.epochs):
                # Training
                train_loss, train_acc, train_diag_acc, train_mel_acc = self.trainer.train_epoch(train_loader)
                
                # Validation
                val_results = self.trainer.validate_epoch(val_loader)
                val_loss, val_acc, val_diag_acc, val_mel_acc = val_results[:4]
                
                # Update learning rate
                self.trainer.step_scheduler()
                
                # Logging
                if epoch % 5 == 0 or epoch == args.epochs - 1:
                    self.logger.info(
                        f"Epoch {epoch+1}/{args.epochs} - "
                        f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f} - "
                        f"Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f} - "
                        f"LR: {self.trainer.get_current_lr():.6f}"
                    )
                
                # Save best model for this fold
                if val_acc > best_val_accuracy:
                    best_val_accuracy = val_acc
                    checkpoint_path = f"checkpoints/best_model_fold_{fold}.pt"
                    save_model_checkpoint(
                        self.model, self.trainer.optimizer, epoch, 
                        val_loss, val_acc, checkpoint_path
                    )
                
                # Early stopping
                if self.trainer.should_early_stop(val_loss):
                    self.logger.info(f"Early stopping at epoch {epoch+1}")
                    break
            
            # Evaluate on validation set
            self.logger.info(f"Fold {fold+1} completed. Best validation accuracy: {best_val_accuracy:.4f}")
            fold_results.append(best_val_accuracy)
        
        # Summary of cross-validation results
        self.logger.info(f"\n{'='*50}")
        self.logger.info("CROSS-VALIDATION SUMMARY")
        self.logger.info(f"{'='*50}")
        
        for i, accuracy in enumerate(fold_results):
            self.logger.info(f"Fold {i+1}: {accuracy:.4f}")
        
        mean_accuracy = np.mean(fold_results)
        std_accuracy = np.std(fold_results)
        
        self.logger.info(f"Mean Accuracy: {mean_accuracy:.4f} ± {std_accuracy:.4f}")
        
        # Save the best overall model
        best_fold = np.argmax(fold_results)
        best_model_path = f"checkpoints/best_model_fold_{best_fold}.pt"
        
        if os.path.exists(best_model_path):
            # Copy best fold model to final model path
            import shutil
            shutil.copy2(best_model_path, Config.BEST_MODEL_PATH)
            self.logger.info(f"Best model (Fold {best_fold+1}) saved to {Config.BEST_MODEL_PATH}")
    
    def evaluate_model(self, args):
        """Evaluate the trained model."""
        self.logger.info("Evaluating model...")
        
        # Initialize model
        self.initialize_model()
        
        # Load model checkpoint
        if not os.path.exists(args.model_checkpoint):
            raise FileNotFoundError(f"Model checkpoint not found: {args.model_checkpoint}")
        
        self.logger.info(f"Loading model from {args.model_checkpoint}")
        epoch, loss, accuracy = load_model_checkpoint(
            self.model, None, args.model_checkpoint
        )
        self.logger.info(f"Loaded model from epoch {epoch} with accuracy {accuracy:.4f}")
        
        # Load data
        df = self.load_data()
        
        # Create test data loader (use last 20% as test set)
        test_size = int(0.2 * len(df))
        test_df = df[-test_size:]
        
        test_dataset = self.data_processor.create_data_loaders(
            test_df, fold_idx=None, batch_size=args.batch_size
        )[1]  # Use validation loader settings
        
        # Evaluate
        self.model.eval()
        all_diagnosis_targets = []
        all_diagnosis_predictions = []
        all_diagnosis_probabilities = []
        all_melanocytic_targets = []
        all_melanocytic_predictions = []
        all_melanocytic_probabilities = []
        
        with torch.no_grad():
            for batch in tqdm(test_dataset, desc="Evaluating"):
                images = batch['image'].to(Config.DEVICE)
                metadata = batch['metadata'].to(Config.DEVICE)
                diagnosis_targets = batch['diagnosis_target']
                melanocytic_targets = batch['melanocytic_target']
                
                # Forward pass
                diagnosis_outputs, melanocytic_outputs = self.model(images, metadata)
                
                # Get predictions and probabilities
                diagnosis_probs = torch.softmax(diagnosis_outputs, dim=1).cpu()
                melanocytic_probs = torch.softmax(melanocytic_outputs, dim=1).cpu()
                
                _, diagnosis_preds = torch.max(diagnosis_outputs, 1)
                _, melanocytic_preds = torch.max(melanocytic_outputs, 1)
                
                # Collect results
                all_diagnosis_targets.extend(diagnosis_targets.numpy())
                all_diagnosis_predictions.extend(diagnosis_preds.cpu().numpy())
                all_diagnosis_probabilities.extend(diagnosis_probs.numpy())
                
                all_melanocytic_targets.extend(melanocytic_targets.numpy())
                all_melanocytic_predictions.extend(melanocytic_preds.cpu().numpy())
                all_melanocytic_probabilities.extend(melanocytic_probs.numpy())
        
        # Calculate metrics for diagnosis prediction
        diagnosis_metrics = evaluate_model(
            all_diagnosis_targets, all_diagnosis_predictions, 
            np.array(all_diagnosis_probabilities),
            target_names=self.data_processor.get_class_names('diagnosis')
        )
        
        # Calculate metrics for melanocytic prediction
        melanocytic_metrics = evaluate_model(
            all_melanocytic_targets, all_melanocytic_predictions,
            np.array(all_melanocytic_probabilities),
            target_names=self.data_processor.get_class_names('melanocytic')
        )
        
        # Display results
        print(format_metrics_output(diagnosis_metrics, "DIAGNOSIS CLASSIFICATION RESULTS"))
        print(format_metrics_output(melanocytic_metrics, "MELANOCYTIC CLASSIFICATION RESULTS"))
        
        # Plot confusion matrices
        plot_confusion_matrix(
            diagnosis_metrics['confusion_matrix'],
            self.data_processor.get_class_names('diagnosis'),
            title="Diagnosis Classification Confusion Matrix",
            save_path="visualizations/diagnosis_confusion_matrix.png"
        )
        
        plot_confusion_matrix(
            melanocytic_metrics['confusion_matrix'],
            self.data_processor.get_class_names('melanocytic'),
            title="Melanocytic Classification Confusion Matrix",
            save_path="visualizations/melanocytic_confusion_matrix.png"
        )
    
    def predict_single(self, args):
        """Make prediction on a single image."""
        self.logger.info(f"Making prediction for image: {args.image}")
        
        # Initialize model
        self.initialize_model()
        
        # Load model checkpoint
        if not os.path.exists(args.model_checkpoint):
            raise FileNotFoundError(f"Model checkpoint not found: {args.model_checkpoint}")
        
        load_model_checkpoint(self.model, None, args.model_checkpoint)
        
        # Prepare metadata dictionary
        metadata_dict = {
            'age_approx': args.age,
            'anatom_site_general': args.site,
            'sex': args.sex,
            'anatom_site_special': getattr(args, 'site_special', ''),
            'concomitant_biopsy': getattr(args, 'biopsy', False),
            'diagnosis_confirm_type': getattr(args, 'confirm_type', ''),
            'image_type': getattr(args, 'image_type', 'dermoscopic')
        }
        
        # Prepare input data
        image_tensor, metadata_tensor = self.data_processor.prepare_single_prediction(
            args.image, metadata_dict
        )
        
        # Make prediction
        self.model.eval()
        with torch.no_grad():
            image_tensor = image_tensor.to(Config.DEVICE)
            metadata_tensor = metadata_tensor.to(Config.DEVICE)
            
            diagnosis_output, melanocytic_output = self.model(image_tensor, metadata_tensor)
            
            # Get probabilities
            diagnosis_probs = torch.softmax(diagnosis_output, dim=1).cpu().numpy()[0]
            melanocytic_probs = torch.softmax(melanocytic_output, dim=1).cpu().numpy()[0]
            
            # Get predictions
            diagnosis_pred = torch.argmax(diagnosis_output, dim=1).cpu().numpy()[0]
            melanocytic_pred = torch.argmax(melanocytic_output, dim=1).cpu().numpy()[0]
        
        # Format results
        diagnosis_classes = self.data_processor.get_class_names('diagnosis')
        melanocytic_classes = self.data_processor.get_class_names('melanocytic')
        
        print(f"\n{'='*50}")
        print("PREDICTION RESULTS")
        print(f"{'='*50}")
        print(f"Image: {args.image}")
        print(f"Metadata: {metadata_dict}")
        print(f"\nDiagnosis Prediction:")
        print(f"  Predicted Class: {diagnosis_classes[diagnosis_pred]}")
        print(f"  Confidence: {diagnosis_probs[diagnosis_pred]:.4f}")
        print(f"\nTop 3 Diagnosis Probabilities:")
        
        # Sort diagnosis probabilities
        diagnosis_indices = np.argsort(diagnosis_probs)[::-1]
        for i in range(min(3, len(diagnosis_classes))):
            idx = diagnosis_indices[i]
            print(f"  {diagnosis_classes[idx]}: {diagnosis_probs[idx]:.4f}")
        
        print(f"\nMelanocytic Prediction:")
        print(f"  Predicted Class: {melanocytic_classes[melanocytic_pred]}")
        print(f"  Confidence: {melanocytic_probs[melanocytic_pred]:.4f}")
        print(f"  Probabilities: Non-melanocytic: {melanocytic_probs[0]:.4f}, Melanocytic: {melanocytic_probs[1]:.4f}")
        print(f"{'='*50}")

def main():
    """Main CLI function."""
    parser = argparse.ArgumentParser(
        description="Sophisticated Skin Lesion Classification System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Training
  python lesion_classifier.py --train --epochs 50 --batch_size 32 --lr 0.001
  
  # Evaluation
  python lesion_classifier.py --eval --model_checkpoint checkpoints/best_model.pt
  
  # Single prediction
  python lesion_classifier.py --predict --image ISIC_0053509.jpg --age 55 --site "head/neck" --sex male
        """
    )
    
    # Mode selection
    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument('--train', action='store_true', help='Train the model')
    mode_group.add_argument('--eval', action='store_true', help='Evaluate the model')
    mode_group.add_argument('--predict', action='store_true', help='Make prediction on single image')
    
    # Training arguments
    parser.add_argument('--epochs', type=int, default=Config.NUM_EPOCHS, help='Number of training epochs')
    parser.add_argument('--batch_size', type=int, default=Config.BATCH_SIZE, help='Batch size')
    parser.add_argument('--lr', type=float, default=Config.LEARNING_RATE, help='Learning rate')
    
    # Model arguments
    parser.add_argument('--model_checkpoint', type=str, default=Config.BEST_MODEL_PATH, 
                       help='Path to model checkpoint')
    parser.add_argument('--backbone', type=str, default=Config.BACKBONE, 
                       choices=['efficientnet_v2_s', 'resnet50', 'densenet121'],
                       help='CNN backbone architecture')
    
    # Prediction arguments
    parser.add_argument('--image', type=str, help='Path to image for prediction')
    parser.add_argument('--age', type=int, help='Patient age')
    parser.add_argument('--site', type=str, help='Anatomical site (e.g., "head/neck", "anterior torso")')
    parser.add_argument('--sex', type=str, choices=['male', 'female'], help='Patient sex')
    parser.add_argument('--site_special', type=str, help='Special anatomical site')
    parser.add_argument('--biopsy', action='store_true', help='Concomitant biopsy performed')
    parser.add_argument('--confirm_type', type=str, help='Diagnosis confirmation type')
    parser.add_argument('--image_type', type=str, default='dermoscopic', help='Image type')
    
    args = parser.parse_args()
    
    # Validate arguments
    if args.predict:
        if not args.image or not args.age or not args.site or not args.sex:
            parser.error("--predict requires --image, --age, --site, and --sex")
    
    # Update config with command line arguments
    if hasattr(args, 'lr'):
        Config.LEARNING_RATE = args.lr
    if hasattr(args, 'backbone'):
        Config.BACKBONE = args.backbone
    
    # Initialize CLI application
    try:
        cli = SkinLesionCLI()
        
        if args.train:
            cli.train_model(args)
        elif args.eval:
            cli.evaluate_model(args)
        elif args.predict:
            cli.predict_single(args)
            
    except Exception as e:
        logging.error(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
